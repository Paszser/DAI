def hello():
    return hw()
    
def hw():
    cadena = "<h1>Prueba</h1>"
    cadena += "<h2>Probando</h2>"
    cadena += "<div>Hello World.</div>"
    return cadena


