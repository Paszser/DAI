from django import forms
from .models import Galeria, Cuadro

class FormularioGaleria(forms.ModelForm):
    class Meta:
        model = Galeria
        fields = '__all__'
        widgets = {}

class FormularioCuadro(forms.ModelForm):
    class Meta:
        model = Cuadro
        fields = '__all__'
        widgets = {}